# netflix_clone

A new Flutter application to learn animation and basic ui components..
## Assets credit to dribbble artist
## Getting Started

This project is a starting point for a Flutter application.
<br>
<img src="https://user-images.githubusercontent.com/24698014/59196265-d0303700-8bab-11e9-928b-9a0b57958439.png" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/59196271-d32b2780-8bab-11e9-9650-ca6f7c0cdbc8.png" width="280" height="550">
<br>
<br>
Happy learning. :+1:
If you found this project useful, then please consider giving it a :star: on Github and sharing it with your friends via social media.
### Show some :heart: and star the repo to support the project
if you like my work support me 
## Project Created & Maintained By

### divyam joshi
# Donate

> If you found this project helpful or you learned something from the source code and want to appreciate
> 
><a href="https://www.buymeacoffee.com/dvmjoshi" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>
> - [PayPal](https://paypal.me/divyamjoshi)
<br>


A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.io/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.


## License

```
The MIT License

Copyright (c) 2019 Divyam Joshi

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
