class BMovies{
  String Image;
  int Boxc;
  BMovies(this.Image);
}
 List<BMovies> bmovies1=[
   BMovies(
       'https://boundingintocomics.com/files/2019/03/2019.03.21-05.04-boundingintocomics-5c93c41d43700.png')
,BMovies('https://initiate.alphacoders.com/images/100/cropped-1920-1080-1003220.png?3768')
   ,
   BMovies(
       'https://in.bookmyshow.com/entertainment/wp-content/uploads/2019/04/Shazam_960x540.jpg')
   ,
   BMovies(
       'http://t2.gstatic.com/images?q=tbn:ANd9GcQ-hK4oBcmE5BZk71a4wdZ0xe7w2aru9fUtTTcT_kDZDrYGe4E8')
,BMovies('https://initiate.alphacoders.com/images/971/cropped-1920-1080-971284.jpg?8655'),
  BMovies("https://images.unsplash.com/photo-1529335764857-3f1164d1cb24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"),
  BMovies("https://images.unsplash.com/photo-1542222378-eee3a7696dc9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"),
  BMovies("https://images.unsplash.com/photo-1558507334-57300f59f0bd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"),
  BMovies("https://images.unsplash.com/photo-1557342960-7ea3df1d8630?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"),
];

