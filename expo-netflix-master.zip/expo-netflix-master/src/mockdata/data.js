import dumbData from './dumbData.json';

import myList from './myList.json';
import previews from './previews.json';

export default {
  dumbData,

  myList,
  previews
};
